﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace hagdyuawgdwa
{
    public partial class Form1 : Form
    {
        int red = new Random().Next(0, 255);
        int green = new Random().Next(0, 255);
        int blue = new Random().Next(0, 255);
        Random rnd = new Random();
        bool nah = false;
        string Cleared;
        bool fileAlreadySaved;
        bool fileOpenedAndPathAvailable;
        string filePath;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BackColor = Color.Black;
            label1.ForeColor = Color.White;
            label1.Text = "The current process id is " + Process.GetCurrentProcess().Id.ToString();
            label2.Text = "RGB!";
            Cleared = fastColoredTextBox1.Text;
            fastColoredTextBox1.Size = new Size(600, 402);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Color randomColor = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
            label2.ForeColor = randomColor;
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new About().Show();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            filePath = openFileDialog1.FileName;
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            if (filePath != string.Empty)
            {
                fastColoredTextBox1.OpenFile(openFileDialog1.FileName);
                saveToolStripMenuItem.Enabled = true;
            }
            else
            {
                return;
            }
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = Cleared;
            saveToolStripMenuItem.Enabled = false;
        }

        private void debuggingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(nah == false)
            {
                nah = true;
                label1.Visible = true;
                label2.Visible = true;
                fastColoredTextBox1.Size = new Size(600, 348);
            }
            else
            {
                nah=false;
                label1.Visible = false;
                label2.Visible = false;
                fastColoredTextBox1.Size = new Size(600, 402);
                //600; 348
                //600; 402
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(File.Exists(filePath))
            {
                File.WriteAllText(openFileDialog1.FileName, fastColoredTextBox1.Text);
            }
            
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            if (File.Exists(openFileDialog1.FileName))
            {
                saveToolStripMenuItem.Enabled = true;
            }
        }

        private void saveNewFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
            if(saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog1.FileName, fastColoredTextBox1.Text);
                saveToolStripMenuItem.Enabled=true;
            }
        }
    }
}
