﻿namespace hagdyuawgdwa
{
    partial class AboutBox1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.lol = new System.Windows.Forms.Label();
            this.lol1 = new System.Windows.Forms.Label();
            this.lol2 = new System.Windows.Forms.Label();
            this.lol3 = new System.Windows.Forms.Label();
            this.lol4 = new System.Windows.Forms.TextBox();
            this.okButton = new System.Windows.Forms.Button();
            this.logoPictureBox = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel
            // 
            this.tableLayoutPanel.ColumnCount = 2;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67F));
            this.tableLayoutPanel.Controls.Add(this.logoPictureBox, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.lol, 1, 0);
            this.tableLayoutPanel.Controls.Add(this.lol1, 1, 1);
            this.tableLayoutPanel.Controls.Add(this.lol2, 1, 2);
            this.tableLayoutPanel.Controls.Add(this.lol3, 1, 3);
            this.tableLayoutPanel.Controls.Add(this.lol4, 1, 4);
            this.tableLayoutPanel.Controls.Add(this.okButton, 1, 5);
            this.tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel.Location = new System.Drawing.Point(9, 9);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            this.tableLayoutPanel.RowCount = 6;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel.Size = new System.Drawing.Size(417, 265);
            this.tableLayoutPanel.TabIndex = 0;
            // 
            // lol
            // 
            this.lol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lol.Location = new System.Drawing.Point(143, 0);
            this.lol.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
            this.lol.MaximumSize = new System.Drawing.Size(0, 17);
            this.lol.Name = "lol";
            this.lol.Size = new System.Drawing.Size(271, 17);
            this.lol.TabIndex = 19;
            this.lol.Text = "ATE";
            this.lol.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lol1
            // 
            this.lol1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lol1.Location = new System.Drawing.Point(143, 26);
            this.lol1.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
            this.lol1.MaximumSize = new System.Drawing.Size(0, 17);
            this.lol1.Name = "lol1";
            this.lol1.Size = new System.Drawing.Size(271, 17);
            this.lol1.TabIndex = 0;
            this.lol1.Text = "1.0";
            this.lol1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lol2
            // 
            this.lol2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lol2.Location = new System.Drawing.Point(143, 52);
            this.lol2.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
            this.lol2.MaximumSize = new System.Drawing.Size(0, 17);
            this.lol2.Name = "lol2";
            this.lol2.Size = new System.Drawing.Size(271, 17);
            this.lol2.TabIndex = 21;
            this.lol2.Text = "OSS";
            this.lol2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lol3
            // 
            this.lol3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lol3.Location = new System.Drawing.Point(143, 78);
            this.lol3.Margin = new System.Windows.Forms.Padding(6, 0, 3, 0);
            this.lol3.MaximumSize = new System.Drawing.Size(0, 17);
            this.lol3.Name = "lol3";
            this.lol3.Size = new System.Drawing.Size(271, 17);
            this.lol3.TabIndex = 22;
            this.lol3.Text = "youtube.com/@UbeydeDonmez";
            this.lol3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lol4
            // 
            this.lol4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lol4.Location = new System.Drawing.Point(143, 107);
            this.lol4.Margin = new System.Windows.Forms.Padding(6, 3, 3, 3);
            this.lol4.Multiline = true;
            this.lol4.Name = "lol4";
            this.lol4.ReadOnly = true;
            this.lol4.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.lol4.Size = new System.Drawing.Size(271, 126);
            this.lol4.TabIndex = 23;
            this.lol4.TabStop = false;
            this.lol4.Text = "lol haha yes i ATE pitza";
            // 
            // okButton
            // 
            this.okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.okButton.Location = new System.Drawing.Point(339, 239);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 24;
            this.okButton.Text = "&OK";
            // 
            // logoPictureBox
            // 
            this.logoPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logoPictureBox.Image = global::hagdyuawgdwa.Properties.Resources.winpe;
            this.logoPictureBox.Location = new System.Drawing.Point(3, 3);
            this.logoPictureBox.Name = "logoPictureBox";
            this.tableLayoutPanel.SetRowSpan(this.logoPictureBox, 6);
            this.logoPictureBox.Size = new System.Drawing.Size(131, 259);
            this.logoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.logoPictureBox.TabIndex = 12;
            this.logoPictureBox.TabStop = false;
            // 
            // AboutBox1
            // 
            this.AcceptButton = this.okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 283);
            this.Controls.Add(this.tableLayoutPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AboutBox1";
            this.Padding = new System.Windows.Forms.Padding(9);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "About ATE";
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.PictureBox logoPictureBox;
        private System.Windows.Forms.Label lol;
        private System.Windows.Forms.Label lol1;
        private System.Windows.Forms.Label lol2;
        private System.Windows.Forms.Label lol3;
        private System.Windows.Forms.TextBox lol4;
        private System.Windows.Forms.Button okButton;
    }
}
